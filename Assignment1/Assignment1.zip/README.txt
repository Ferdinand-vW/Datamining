Datamining - Assignment 1

Ferdinand van Walree - 3874389
Rizkiyanto - 4234634

The folder workspace includes our RStudio project. (.RData is our R workspace and is a hidden file, but it can still be seen in RStudio)
Programcode.txt also includes our entire program code, but in a plaintext file
Tree.png is a human-readable version of the tree that was constructed using test data with nmin of 15 and minleaf of 
Report.pdf is the report of our analysis